package com.example.demo;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
@RestController
public class HomeController {
@GetMapping("home")
public String msg() {
	return "I'm the Home Service. You can create a Home page and display";
}
}
